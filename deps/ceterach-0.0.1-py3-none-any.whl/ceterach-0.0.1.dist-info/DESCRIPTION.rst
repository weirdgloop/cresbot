ceterach
========

An interface for interacting with MediaWiki.

