Copyright (c) 2013 Daniel Bader (http://dbader.org)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

Download-URL: https://github.com/dbader/schedule/tarball/0.3.1
Description: schedule
        ========
        
        
        .. image:: https://api.travis-ci.org/dbader/schedule.png
                :target: https://travis-ci.org/dbader/schedule
        
        .. image:: https://coveralls.io/repos/dbader/schedule/badge.png
                :target: https://coveralls.io/r/dbader/schedule
        
        .. image:: https://pypip.in/v/schedule/badge.png
                :target: https://pypi.python.org/pypi/schedule
        
        .. image:: https://pypip.in/d/schedule/badge.png
                :target: https://pypi.python.org/pypi/schedule
        
        Python job scheduling for humans.
        
        An in-process scheduler for periodic jobs that uses the builder pattern
        for configuration. Schedule lets you run Python functions (or any other
        callable) periodically at pre-determined intervals using a simple,
        human-friendly syntax.
        
        Inspired by `Adam Wiggins' <https://github.com/adamwiggins>`_ article `"Rethinking Cron" <http://adam.heroku.com/past/2010/4/13/rethinking_cron/>`_ (`Google cache <http://webcache.googleusercontent.com/search?q=cache:F14k7BNcufsJ:adam.heroku.com/past/2010/4/13/rethinking_cron/+&cd=1&hl=de&ct=clnk&gl=de>`_) and the `clockwork <https://github.com/tomykaira/clockwork>`_ Ruby module.
        
        Features
        --------
        - A simple to use API for scheduling jobs.
        - Very lightweight and no external dependencies.
        - Excellent test coverage.
        - Tested on Python 2.7 and 3.4
        
        Usage
        -----
        
        .. code-block:: bash
        
            $ pip install schedule
        
        .. code-block:: python
        
            import schedule
            import time
        
            def job():
                print("I'm working...")
        
            schedule.every(10).minutes.do(job)
            schedule.every().hour.do(job)
            schedule.every().day.at("10:30").do(job)
            schedule.every().monday.do(job)
            schedule.every().wednesday.at("13:15").do(job)
        
            while True:
                schedule.run_pending()
                time.sleep(1)
        
        FAQ
        ---
        
        In lieu of a full documentation (coming soon) check out this set of `frequently asked questions <https://github.com/dbader/schedule/blob/master/FAQ.rst>`_ for solutions to some common questions.
        
        Meta
        ----
        
        Daniel Bader - `@dbader_org <https://twitter.com/dbader_org>`_ - mail@dbader.org
        
        Distributed under the MIT license. See ``LICENSE.txt`` for more information.
        
        https://github.com/dbader/schedule
        
        
        .. :changelog:
        
        History
        -------
        
        0.3.1 (2014-09-03)
        ++++++++++++++++++
        
        - Fixed an issue with unicode handling in setup.py that was causing trouble on Python 3 and Debian (https://github.com/dbader/schedule/issues/27). Thanks to @waghanza for reporting it.
        - Added an FAQ item to describe how to deal with job functions that throw exceptions. Thanks @mplewis.
        
        0.3.0 (2014-06-14)
        ++++++++++++++++++
        
        - Added support for scheduling jobs on specific weekdays. Example: ``schedule.every().tuesday.do(job)`` or ``schedule.every().wednesday.at("13:15").do(job)`` (Thanks @abultman.)
        - Run tests against Python 2.7 and 3.4. Python 3.3 should continue to work but we're not actively testing it on CI anymore.
        
        0.2.1 (2013-11-20)
        ++++++++++++++++++
        
        - Fixed history (no code changes).
        
        0.2.0 (2013-11-09)
        ++++++++++++++++++
        
        - This release introduces two new features in a backwards compatible way:
        - Allow jobs to cancel repeated execution: Jobs can be cancelled by calling ``schedule.cancel_job()`` or by returning ``schedule.CancelJob`` from the job function. (Thanks to @cfrco and @matrixise.)
        - Updated ``at_time()`` to allow running jobs at a particular time every hour. Example: ``every().hour.at(':15').do(job)`` will run ``job`` 15 minutes after every full hour. (Thanks @mattss.)
        - Refactored unit tests to mock ``datetime`` in a cleaner way. (Thanks @matts.)
        
        0.1.11 (2013-07-30)
        +++++++++++++++++++
        
        - Fixed an issue with ``next_run()`` throwing a ``ValueError`` exception when the job queue is empty. Thanks to @dpagano for pointing this out and thanks to @mrhwick for quickly providing a fix.
        
        0.1.10 (2013-06-07)
        +++++++++++++++++++
        
        - Fixed issue with ``at_time`` jobs not running on the same day the job is created (Thanks to @mattss)
        
        0.1.9 (2013-05-27)
        ++++++++++++++++++
        
        - Added ``schedule.next_run()``
        - Added ``schedule.idle_seconds()``
        - Args passed into ``do()`` are forwarded to the job function at call time
        - Increased test coverage to 100%
        
        
        0.1.8 (2013-05-21)
        ++++++++++++++++++
        
        - Changed default ``delay_seconds`` for ``schedule.run_all()`` to 0 (from 60)
        - Increased test coverage
        
        0.1.7 (2013-05-20)
        ++++++++++++++++++
        
        - API change: renamed ``schedule.run_all_jobs()`` to ``schedule.run_all()``
        - API change: renamed ``schedule.run_pending_jobs()`` to ``schedule.run_pending()``
        - API change: renamed ``schedule.clear_all_jobs()`` to ``schedule.clear()``
        - Added ``schedule.jobs``
        
        0.1.6 (2013-05-20)
        ++++++++++++++++++
        
        - Fix packaging
        - README fixes
        
        0.1.4 (2013-05-20)
        ++++++++++++++++++
        
        - API change: renamed ``schedule.tick()`` to ``schedule.run_pending_jobs()``
        - Updated README and ``setup.py`` packaging
        
        0.1.0 (2013-05-19)
        ++++++++++++++++++
        
        - Initial release
        
Keywords: schedule,periodic,jobs,scheduling,clockwork,cron
Platform: UNKNOWN
Classifier: Intended Audience :: Developers
Classifier: License :: OSI Approved :: MIT License
Classifier: Programming Language :: Python :: 2.7
Classifier: Programming Language :: Python :: 3.4
Classifier: Natural Language :: English
